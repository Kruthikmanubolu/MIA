import numpy as np

# Load the .npy files
x = np.load('data_complete2.npz')

# Determine the length of the array
length_of_array = len(x)

print("Length of the array:", length_of_array)
