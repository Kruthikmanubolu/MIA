import os
import numpy as np
import tarfile

def prepare_purchase_data(batch_size=100):
    DATASET_PATH = './datasets/purchase'
    DATASET_NAME = 'dataset_purchase'
    DATASET_NUMPY = 'data.npz'

    if not os.path.isdir(DATASET_PATH):
        os.makedirs(DATASET_PATH)
        print("Dataset directory created.")

    DATASET_FILE = os.path.join(DATASET_PATH, DATASET_NAME)
    DOWNLOADED_FILE = 'dataset_purchase.tgz'  # Replace 'path_to_downloaded_file.tgz' with the actual path to your downloaded file

    if not os.path.isfile(DATASET_FILE):
        print('Extracting the dataset...')
        tar = tarfile.open(DOWNLOADED_FILE)
        tar.extractall(path=DATASET_PATH)
        tar.close()
        print('Dataset extracted.')
    else:
        print('Dataset already exists.')

    if not os.path.exists(os.path.join(DATASET_PATH, DATASET_NUMPY)):
        print('Reading dataset...')
        data_set = np.genfromtxt(DATASET_FILE, delimiter=',')
        print('Finish reading!')
        x = data_set[:, 1:].astype(np.float64)
        y = (data_set[:, 0]).astype(np.int32) - 1
        np.savez(os.path.join(DATASET_PATH, DATASET_NUMPY), x=x, y=y)
        print('Dataset saved to NPZ file.')
    else:
        print('NPZ file already exists.')

# Call the function
prepare_purchase_data()
